﻿using ReactiveUI;

namespace UsersTables.ViewModels;

public class ViewModelBase : ReactiveObject
{
}
