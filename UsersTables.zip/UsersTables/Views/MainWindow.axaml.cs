﻿using Avalonia.Controls;

namespace UsersTables.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
