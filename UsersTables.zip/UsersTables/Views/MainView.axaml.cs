﻿using Avalonia.Controls;
using ReactiveUI;

namespace UsersTables.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
