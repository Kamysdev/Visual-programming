using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace UsersTables;

public partial class EditUser : Window
{
    public EditUser()
    {
        InitializeComponent();
    }
}