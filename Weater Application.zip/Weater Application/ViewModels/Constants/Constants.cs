﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weater_Application.ViewModels;

internal class Constants
{
    public const string API_KEY = "e2ed2c756067721c0b6d55a31ca957d0";
    public const string API_BASE_URL = "http://api.openweathermap.org/data/2.5/";
}
