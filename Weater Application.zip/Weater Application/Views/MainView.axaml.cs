﻿using Avalonia.Controls;

namespace Weater_Application.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
